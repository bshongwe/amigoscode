package com.ernest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
